#!/usr/bin/env python
# Geeky Theory - www.geekytheory.com
# sudo apt-get install python-serial

from Adafruit_CharLCD import Adafruit_CharLCD
from db_conn import DBConn
from subprocess import *
from datetime import *
import time
import serial

#Configuracion del LCD
lcd = Adafruit_CharLCD()
lcd.begin(16,2)
db = DBConn()

#Comunicacion con el arduino
arduino=serial.Serial('/dev/ttyACM0',baudrate=9600, timeout = 5.0)
arduino.open()

#Bienvenida al sistema
lcd.home()
lcd.message("Sistema de Moni")
lcd.setCursor(0,1)
lcd.message("toreo de temp")
time.sleep(2)
i = 0
while True: 
	
	#Estabilizador de lecturas 
	if i < 5:
		time.sleep(3)
		i += 1
		lectura = arduino.readline() #esta la alternativa read(i) para leer en un bucle bytexbyte
		lcd.clear()
		lcd.home()
		lcd.message("inicializando...")
		#print "inicializando ..."
	#Lecturas corregidas
	else:
		time.sleep(5)
		lectura = arduino.readline() #esta la alternativa read(i) para leer en un bucle bytexbyte
		valores = lectura.split()
		#print valores

	        #creamos las consultas
        	query = "INSERT INTO LECTURAS (SENSOR1, SENSOR2, SENSOR3, SENSOR4, SENSOR5, SENSOR6, SENSOR7, SENSOR8, SENSOR9, SENSOR10, SENSOR11, SENSOR12) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
	        values = (valores[0], valores[1], valores[2], valores[3], valores[4], valores[5], valores[6], valores[7], valores[8], valores[9], valores[10], valores[11])
        	db.ejecutar(query, values)

	        #Mostrar los datos en el display
                lcd.clear() #Limpiamos la pantalla        
	        lcd.home()  #Colocamos el cursor al inicio   
        	lcd.message("Monitor de ")
	        lcd.setCursor(0,1) #Colocamos el cursor en la segunda fila 0-COL 1-ROW
	        lcd.message("Temperatura")
arduino.close()
